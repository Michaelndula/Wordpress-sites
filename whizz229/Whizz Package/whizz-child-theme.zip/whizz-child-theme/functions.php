<?php
/**
 * The template includes necessary functions for theme.
 *
 * @package whizz
 * @since 1.0
 */
